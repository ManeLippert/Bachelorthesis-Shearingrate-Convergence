n=    [4  6  8  10  12  14  16  18  20  22  24];

linear_summary 

load nm; 
load np; 

figure(51)
hold off 

conv = sqrt(2.)*0.625 / 1.70;

plot(n,conv*nm(:,2),'rx-'); 
hold on 
plot(n,conv*np(:,2),'bd-'); 

plot(n100,gamma100,'ko-')

xlabel('Toroidal mode number'); 
ylabel('\gamma a / c_s'); 


%figure(52)
%hold off 
%plot(n,conv*nm(:,3),'rx-'); 
%hold on 
%plot(n,conv*np(:,3),'bd-'); 
%plot(n,-omega_np,'ko-')
%
%xlabel('Toroidal mode number')
%ylabel('\omega a / c_s')


load rhoscan
x = [ 50 100 200 400]; 
xx = x; 
xx(5) = 800;
xx(6) = 1600;
figure(53);
hold off;  
%loglog(x,gammas_np,'ko-'); 
gnsp = load('latest_rho_scan_orb.dat')
loglog(x(1:3),gnsp,'ko-'); 

hold on 
plot(xx,conv*rhoscan(:,2),'rx-') 
plot([40 2000],[ 0.238636*conv  0.238636*conv],'b--')
axis([40 2000 0.04 0.14]); 
xlabel('1/\rho_*')
ylabel('\gamma [c_s / a]') 
title('Scaling of the growth rate with rho_*') 

load nr 
%gkw_rhos50 
figure(51); 
% plot(n,gamma,'ko-')
plot(n50,gamma50,'ko-');
ns = size(nr,1); 
nnn = linspace(1,ns,ns); 
plot(nnn,conv*nr(:,2),'rx-'); 

load ns 
plot(nnn,conv*ns(:,2),'bd-');

