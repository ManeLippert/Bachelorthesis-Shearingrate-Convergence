% path('/afs/ipp-garching.mpg.de/home/b/bottino/matlab/VIST',path)
% [nemo, info]=nemorb({'/ptmp/bottino/gkw/n6'},{'n6'})
% spectrum_movie(nemo,'deuterium') %to get kthetarho
% nemo.tmin_rf=3000; nemorb_linear_omega(nemo,0.5,'deuterium',1);
% nemorb_jdote_new(nemo,3000,5000000,1);

n100 = [2:2:24]
gamma100 =[0.0051958806 0.019562116 0.041060387  0.063736941 0.082615626 0.093511599 0.097514801 0.093845822 0.083915906 0.067811699 0.048643789 0.025629004]
omega100 =[] %cs/a

n50=[1 2 3 4 5 6 7 8 9 10 11 12]
gamma50=[0.0029666686 0.0060041117 0.014914958 0.035694282  0.051502335 0.060333041 0.062853556 0.059979938  0.051712185 0.038858914  0.02146566 0.0014124498]



gammas_np=[ 0.050724021       0.081609988      0.088525858   0.093681627 ];


%figure
%plot(n50,gamma50,'ko-')
%hold on
%plot(n100,gamma100,'ro-')
%xlabel('n')
%ylabel('[c_s/a]')
%
