function [spc, xprkn] = insert_impurity(spc_in, xprkn_in, Zeff, Zimp, Aimp, TimpovTi, mref, Cz);
% function [spc, xprkn] = insert_impurity(spc_in, xprkn_in, Zeff, Zimp, Aimp, [TimpovTi], [mref], [Cz]);

% Introduces a third species with Z = Zimp for impurity
% according to the value of Zeff given in input;
% Assumes as usual spc(1) ions (deuterium) and spc(2) electrons !
% same gradients as the main ion species are taken.
%

%;

if ~exist('TimpovTi')
TimpovTi = 1;
end;

if ~exist('mref')
mref = 2;
end;

if ~exist('Cz')
     Cz = 0; %% not used; otherwise Zeff used ONLY in knobs for collisionality !
end;

if Cz == 0 %% uses Zeff to determine concentrations !
spc = spc_in;
spc(3) = spc(1);
spc(1).dens = spc(2).dens*(Zimp-Zeff)/(Zimp-1);

spc(3).z = Zimp;
spc(3).mass = Aimp./mref;
spc(3).dens = spc(2).dens*(Zeff-1)/(Zimp-1)/Zimp;
spc(3).temp = spc(1).temp*TimpovTi;
%
else % uses Cz to define densities
%
spc = spc_in;
spc(3) = spc(1);
spc(1).dens = spc(2).dens*(1-Cz*Zimp);

spc(3).z = Zimp;
spc(3).mass = Aimp./mref;
spc(3).dens = Cz*spc(2).dens;
spc(3).temp = spc(1).temp*TimpovTi;
end


%
% Collision frequencies
%
spc(1).vnewk = spc(2).vnewk * ...
sqrt(spc(2).mass/spc(1).mass) *(spc(2).temp/spc(1).temp)^1.5 *spc(1).z^2* ...
( ...
  (spc(1).dens/spc(2).dens)*spc(1).z^2 *2 /...
  (1+(spc(1).mass/spc(1).mass*spc(1).temp/spc(1).temp)^0.5) + ...
  (spc(2).dens/spc(2).dens)*spc(2).z^2 *2 /...
  (1+(spc(1).mass/spc(2).mass*spc(2).temp/spc(1).temp)^0.5) + ...
  (spc(3).dens/spc(2).dens)*spc(3).z^2 *2 /...
  (1+(spc(1).mass/spc(3).mass*spc(3).temp/spc(1).temp)^0.5) ...
  );
spc(3).vnewk = spc(2).vnewk * ...
sqrt(spc(2).mass/spc(3).mass) *(spc(2).temp/spc(3).temp)^1.5 *spc(3).z^2* ...
( ...
  (spc(1).dens/spc(2).dens)*spc(1).z^2 *2 /...
  (1+(spc(3).mass/spc(1).mass*spc(1).temp/spc(3).temp)^0.5) + ...
  (spc(2).dens/spc(2).dens)*spc(2).z^2 *2 /...
  (1+(spc(3).mass/spc(2).mass*spc(2).temp/spc(3).temp)^0.5) + ...
  (spc(3).dens/spc(2).dens)*spc(3).z^2 *2 /...
  (1+(spc(3).mass/spc(3).mass*spc(3).temp/spc(3).temp)^0.5) ...
  );

xprkn = xprkn_in;
xprkn.zeff = Zeff;


