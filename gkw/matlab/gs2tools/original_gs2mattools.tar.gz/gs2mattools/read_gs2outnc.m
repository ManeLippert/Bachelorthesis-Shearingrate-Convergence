function ncout = read_gs2outnc(flnm, pth)
%
% function ncout = read_gs2outnc(flnm, [pth])
%
% Input. 
%       flnm :  filename
%       pth  :  path (optional: by default looks in user's directory ~/gs2run/out.nc)
%
% Output.
% structure ncout with all the variables
%
% CLA 10.02.07
%

usrnm = find_usrnm;
%
if ~exist('pth')
pth = ['/u/' usrnm '/gs2run/out.nc/'];
end
if pth == 1
pth = ['/u/' usrnm '/gs2run/gs2archive/out.nc/'];
end

totflnm = [pth flnm];
wetcdf on;
znames = ncload(totflnm);
wetcdf off;  

for ij = 1:length(znames);
eval(['ncout.' znames{ij} ' = ' znames{ij} ';']);
end; 
