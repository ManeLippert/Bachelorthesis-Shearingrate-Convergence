function [aky, omavg, qheat, pflux] = read_gs2output(flnm, pth)
%
% function [aky, omavg, qheat, pflux] = read_gs2output(flnm, [pth])
%
% Input. 
%       flnm :  filename
%       pth  :  path (optional: by default looks in user's directory ~/gs2run/output)
%       if pth == 1 looks in user's directory ~/gs2run/gs2archive/output)
% Output.
%       aky   : vector of k_theta values
%       omavg : matrix with complex frequency for each k_theta 
%               omavg(:,1) : real frequency
%               omavg(:,2) : growth rate
%               same normalisations as in gs2 output !
%       qheat and pflux : matrix with heat and particle fluxes 
%                         (same normalisations as in gs2)
%
% Calls read_gs2outtime to check time evolution if not converged
%
% CLA 10.08.03
%

usrnm = find_usrnm;
%
if ~exist('pth')
pth = ['/u/' usrnm '/gs2run/output/'];
end
if pth == 1
pth = ['/u/' usrnm '/gs2run/gs2archive/output/'];
end

totflnm = [pth flnm];
fptr = fopen(totflnm, 'r');
frewind(fptr);
%

iconv = 1;
yk = 0;
while yk == 0
sss = fscanf(fptr,'%s', 1);
if isempty(sss); break; end;
if strcmp(sss, 'converged'), yk = 1; end;
end

if yk == 0
disp([flnm ' not converged']);
iconv = 0;
ync = input('Do you want to check the output ? (0/1)  ');
if ~ync
aky = NaN;
omavg = [NaN NaN];
qheat = [NaN NaN];
pflux = [NaN NaN];
else
[aky, omavg, qheat, pflux, ky] = read_gs2outtime(flnm, pth);
end
end
%
if iconv
ik = 0;
yesik = 0;
while yesik == 0
% looks for locations of aky
yk = 0;
while yk == 0
sss = fscanf(fptr,'%s', 1);
if isempty(sss), yesik = 1; break; end; 
if strcmp(sss, 'aky='), yk = 1; end;
end
if yk == 1
ik = ik+1;
aky(ik) = fscanf(fptr, '%f', 1);
zyk = 0;
while zyk == 0
sss = fscanf(fptr,'%s', 1);
if strcmp(sss, 'omavg/(vt/a)='), zyk = 1; end;
end
omavg(ik,1) = fscanf(fptr, '%f', 1);
omavg(ik,2) = fscanf(fptr, '%f', 1);
zyk = 0;
while zyk == 0
sss = fscanf(fptr,'%s', 1);
if strcmp(sss, 'qheat='), zyk = 1; end;
end
qheat(ik,1) = fscanf(fptr, '%f', 1);
qheat(ik,2) = fscanf(fptr, '%f', 1);
aa = fscanf(fptr, '%f', 1);
if ~isempty(aa); qheat(ik,3) = aa; end;
zyk = 0;
while zyk == 0
sss = fscanf(fptr,'%s', 1);
if strcmp(sss, 'pflux='), zyk = 1; end;
end
pflux(ik,1) = fscanf(fptr, '%f', 1);
pflux(ik,2) = fscanf(fptr, '%f', 1);
aa = fscanf(fptr, '%f', 1);
if ~isempty(aa); pflux(ik,3) = aa; end;
end
end
end
fclose(fptr);
