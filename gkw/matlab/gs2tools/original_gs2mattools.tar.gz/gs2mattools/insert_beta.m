function [xprkn, xpareq] = insert_beta(xprkn_in, ne, Tref, BT0, xpareq, xspc);
% function [xprkn, xpareq] = insert_beta(xprkn_in, ne, Tref, BT0, xpareq, xspc);

NTB2 = ne.*Tref./BT0^2;

xprkn = xprkn_in;
xprkn.fapar = 1;
xprkn.beta =  403. * NTB2 / 1.e5;
if ~exist('xspc');
xspc = 'NaN';
end;
if ~exist('xpareq');
xpareq = 'NaN';
return;
end;

if isfield(xpareq,'beta_prime_input'); % eik equilibrium
xpareq.beta_prime_input = -xprkn.beta.* ...
(xspc(1).dens.*xspc(1).temp.*(xspc(1).fprim+xspc(1).tprim -0.*2) + ...
 xspc(2).dens.*xspc(2).temp.*(xspc(2).fprim+xspc(2).tprim -0.*2));
end

if ~isfield(xpareq,'beta_prime_input'); % s-alpha equilibrium
xpareq.shift = 2*(4*pi)*(2.0/xpareq.pk)^2* NTB2 *1600./1e7* ...
(xspc(2).fprim*(1+xspc(2).temp) + ...
xspc(1).tprim+ xspc(2).temp*xspc(2).tprim);
end;
