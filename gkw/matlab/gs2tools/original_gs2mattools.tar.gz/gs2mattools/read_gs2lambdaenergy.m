function y = read_gs2lambdaenergy(flnm)
%
% function y = read_gs2lambdaenergy(flnm)
% 
% Note GS2 lambda output is already multiplied by spec%dens;
% To compare it with netcdf output fluxes, you have to divide
% these fluxes by spec%dens
%
% CLA, 20.03.07
%
usrnm = find_usrnm;
%
if ~exist('pth')
pth = ['/u/' usrnm '/gs2run/lambda_pfl/'];
end
if isempty(pth)
pth = ['/u/' usrnm '/gs2run/lambda_pfl/'];
end
pthflnm = [pth flnm];

eval(['load ' pthflnm ';']);
eval(['lambdapfl = ' flnm ';']);
  
[aa bb] = size(lambdapfl);
nspec = lambdapfl(end,3);
llspec = aa./nspec;
clear ispc zlambda zlmpflx ztotpfl;
for ij = 1:nspec;
ispc(ij,1:llspec) = (ij-1)*llspec+1:ij*llspec;
end
for ij = 1:nspec;
zlambda(ij,1:llspec) = transpose(lambdapfl(ispc(ij,:), 1));
zlmpflx(ij,1:llspec) = transpose(lambdapfl(ispc(ij,:), 2));
ztotpfl(ij,1:llspec) = transpose(lambdapfl(ispc(ij,:), 4));
[zz ibndps(ij)] = max(abs(zlmpflx(ij,:)));
totpflps(ij) =  ztotpfl(ij,ibndps(ij));
totpfltr(ij) =  ztotpfl(ij,end)-totpflps(ij);
totpfl(ij) =  ztotpfl(ij,end);
end

y.lambda = zlambda;
y.lmbdpflx = zlmpflx;
y.intpflx = ztotpfl;
y.ibndps = ibndps;
y.totpflps = totpflps;
y.totpfltr = totpfltr;
y.totpfl = totpfl;
