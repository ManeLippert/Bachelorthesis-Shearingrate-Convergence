function [yy,eql,xkt,nbspecies,xxspc,xprkn] = ...
gs2in_from_idlmaslov(maslov_file_matlab, rhovalue, drho, optsave);
%
% writes gs2 input file, from the file maslov_file_matlab 
% given in input and which is produced by Mikhail Maslov idl 
% routine extract_gs2 on JAC (default file name gs2.m)
%
% Input variables:
% maslov_file_matlab : file name
% rhovalue: local rho value at which you want the GS2 input
% drho: length in rho of the radial window over which gradients are computed
% optsave : 0/1, 1 if you want to write the file.
%
% cla 10.8.2006
%

if ~exist('optsave'); optsave = 0; end;

eval([ maslov_file_matlab ';']);

rhot = rho; rhot(1) = 0; rhot(21) = 1;
% rhot from Mikhail very strange
% use
rhot = r./max(r);

rhot(find(rhot> rhovalue-drho & rhot< rhovalue+drho))
[ztesm, zgtesm] = interpos(13,r,te./1e3, r, 1e-04,[1 0],[0 0]);
[ztism, zgtism] = interpos(13,r,ti./1e3, r, 1e-04,[1 0],[0 0]);
[znesm, zgnesm] = interpos(13,r,zne./1e19,r, 1e-04,[1 0],[0 0]);
[zqsm, zgqsm]   = interpos(13,rhot,q,rhot,  0,[1 0],[0 0]);
zteprim = -Rgeo.*zgtesm./ztesm;
ztiprim = -Rgeo.*zgtism./ztism;
zneprim = -Rgeo.*zgnesm./znesm;
zshear = rhot./zqsm.*zgqsm;

%
figure;
subplot(1,2,1);
plot(r./max(r),[ztesm; ztism; znesm]);hold on;
subplot(1,2,2);
plot(r./max(r),[zteprim; ztiprim; zneprim]);hold on;
%

zeps = r./Rgeo;
zbetatot = 0.00403.*znesm.*(ztesm+ztism)./bvac.^2;
zbeta_gs2 = 0.00403.*znesm.*ztesm./bvac.^2;
[zbetatsm, zalpha] = interpos(13,r,zbetatot,r,0,[1 0],[0 0]);
zalpha = - zqsm.^2.*Rgeo.*zalpha;


[eql, spc, xprkn, xkt] = read_gs2input('hmsc_start');

eql.eps = interp1(rhot, zeps, rhovalue);
eql.pk = eql.epsl./interp1(rhot,q,rhovalue);
eql.shat = interp1(rhot,zshear,rhovalue);
eql.shift = mean(zalpha(find(rhot> rhovalue-drho & rhot< rhovalue+drho)));
%
xkt.naky       =1;
xkt.ntheta0    =1;
xkt.aky_min    =0.18;
xkt.aky_max    =0.18;
xkt.theta0_min =0.0;
xkt.theta0_max =0.0;
%
nbspecies = 2;
%
xspc(1).z     = 1.0;
xspc(1).mass  = 1.0;
xspc(1).dens  = 1.0;
xspc(1).temp  = 1.0;
xspc(1).tprim = mean(ztiprim(find(rhot> rhovalue-drho & rhot< rhovalue+drho)));
xspc(1).fprim = mean(zneprim(find(rhot> rhovalue-drho & rhot< rhovalue+drho)));
xspc(1).uprim = 0.0;
xspc(1).vnewk = 0.0;
%
xspc(2).z     = -1.0;
xspc(2).mass  = 2.72e-4;
xspc(2).dens  = 1.0;
xspc(2).temp  = interp1(rhot, ztesm./ztism, rhovalue);
xspc(2).tprim = mean(zteprim(find(rhot> rhovalue-drho & rhot< rhovalue+drho)));
xspc(2).fprim = xspc(1).fprim;
xspc(2).uprim = 0.0;
xspc(2).vnewk = 0.0;
%
xprkn.beta = interp1(rhot, zbeta_gs2, rhovalue);
xprkn.zeff = 1.0;
xprkn.fphi = 1.0;
xprkn.fapar = 1.0;
xprkn.faperp = 0.0;
%

xxspc = insert_collisionality(xspc,interp1(rhot,znesm, rhovalue), ...
			      interp1(rhot,ztesm, rhovalue), ...
			      interp1(rhot,Rgeo, rhovalue));
yy = 0;
%
if optsave
flpt = ['JET' num2str(shot) '_' num2str(round(time*10)) '_r' num2str(round(rhovalue*100))];
yy = make_gs2input(flpt,eql,xkt,nbspecies,xxspc,xprkn,'/u/cla/gs2run/input/', 'hmsc_start');
end
