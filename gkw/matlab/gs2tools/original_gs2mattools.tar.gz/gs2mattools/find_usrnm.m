function usrnm = find_usrnm;
% 
% function usrnm = find_usrnm;
%
%aaa = pwd;
%% checks for path containing 'home'
%
%for jj = 1:length(aaa)-3;
%if(strcmp(aaa(jj:jj+3), 'home')); break; end;
%shft = 7;
%end;
%if (jj+3 == length(aaa));
%% It does not contain 'home'
%% looks for /u/cla/
%for jj = 1:length(aaa)-3;
%if(strcmp(aaa(jj:jj+2), '/u/')); break; end;
%end;
%shft = 3;
%end;
%
%usrnm = aaa(jj+shft:jj+shft+2);
usrnm = getenv('USER');
