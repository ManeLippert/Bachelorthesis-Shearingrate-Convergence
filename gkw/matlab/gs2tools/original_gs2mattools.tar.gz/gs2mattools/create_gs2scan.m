% Run the program ... you will be leaded interactively to create the gs2 input scan.
% But first edit your gs2_standard_set.m and provide the standard set 
% over which you wish to make your scan !
% To run this program the names of the structures must be the following:
% xpareq xspc xprkn xkt
%
% CLA 10.08.03
% CLA 24.09.03 Added option for collisionality and one impurity.
%

disp(' ');
disp('Before running this program you should edit your gs2_standard_set.m')
disp('and provide the standard set over which you wish to make your scan!');
disp(' ');
%
aaa = input(['Enter return to load your gs2_standard_set.m \n' ...
	     'if the standard set is already in your workspace enter any number       ']);
%
if isempty(aaa)
gs2_standard_set
else
nbspecies = length(xspc);
end
%
fdnmeq = fieldnames(xpareq);
fdnmkt = fieldnames(xkt);
fdnspc = fieldnames(xspc);
fdnpkn = fieldnames(xprkn);
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('This program allows you to create input scans on a maximum of 3 variables');
disp(' ');
nbs = input('Enter the number of variables on which you want to make a scan ');
if nbs > 3
disp('This program allows you to create input scans on a maximum of 3 variables')
     nbs = 3;
end
disp('Enter the name of the variables on which you want to make a scan');
for js = 1:nbs
vnm{js} = input([num2str(js) ')   '],'s');
%
disp(' ');
yes(js) = 0;
spcidx(js) = 0;
for jf = 1:length(fdnmeq)
     if(strcmp(fdnmeq{jf}, vnm{js})), yes(js) = 1; end
end
for jf = 1:length(fdnmkt)
if(strcmp(fdnmkt{jf}, vnm{js})), yes(js) = 2; 
if (strcmp('aky_min', vnm{js}) | strcmp('aky_max', vnm{js})) & xkt.naky ~= 1;
disp(' WARNING: you cannot change aky_min or aky_max if naky is not 1');
disp(' NOTE: naky has been changed to 1');
xkt.naky = 1;
end
%
end
end

for jf = 1:length(fdnspc)
     if(strcmp(fdnspc{jf}, vnm{js})), yes(js) = 3;
disp([vnm{js} ' is a species input parameter']);
disp(['Do you want to make the scan on ions (1), electrons (2), or both together (3)']);
disp('Note that if you want to make both ion and electron scans separately,');
disp('you have to create two separate scans');
     spcidx(js) = input('Give 1 (ions), 2 (electrons) or 3 (both together) ');
end
end
for jf = 1:length(fdnpkn)
     if(strcmp(fdnpkn{jf}, vnm{js})), yes(js) = 4; end
end
end
%
end
%
clear min max nbofval dum;
for js = 1:nbs
if yes(js) > 0
disp(['Set the values for variable ' vnm{js} '  ']);
min(js) = input(['minimum value of ' vnm{js} '  ']);
max(js) = input(['maximum value of ' vnm{js} '  ']);
nbofval(js) = input(['nb of values between ' num2str(min(js)) ' and ' num2str(max(js)) ' for ' vnm{js} ' ']);
else
disp(['Variable ' vnm{js} ' is not an input for GS2']);
return
end
end
%
disp(' ');
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
optc = 0;
optc = input('Do you want to include collisions ?    (0/1) ');
if optc
ne    = input('Value of ne     ');
Tref  = input('Value of Tref   ');
Rtor  = input('Value of Rtor   ');
end
optz = 0;
optz = input('Do you want to include an impurity ?    (0/1) ');
if optz
Zeff  = input('Value of Zeff   ');
Aimp = input('Value of A imp   ');
Zimp = input('Value of Z imp   ');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
disp(['You are asking for a total of ' num2str(prod(nbofval)) ' GS2 runs']);
disp(' ');
flroot = input('Enter the input filename root  [do not put quotes]   ', 's');
disp('In input filenames first index refers to the value of the first variable,');
disp('second index to the value of the second variable, etc.');
%
%
clear dum;
for js = 1:nbs
dum(js).xvals = linspace(min(js), max(js), nbofval(js));
%
if strcmp(vnm{js},'vnewk');
dum(js).xvals = exp(linspace(log(min(js)), log(max(js)), nbofval(js)));
end;
%
end
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
disp('If you want to provide a specific reference input file');
disp('[otherwise give just return (takes the default file)]');
zflnm = input('Enter the filename  [do not put quotes]     ','s');

if nbs == 1
for j1 = 1:nbofval(1)
script2create
filename = [flroot num2str(j1)];
y = make_gs2input(filename,xpareq,xkt,nbspecies,xspc,xprkn,[ ],zflnm);
end
%
elseif nbs == 2
for j1 = 1:nbofval(1)
for j2 = 1:nbofval(2)
script2create
if nbofval(1) < 10 & nbofval(2) < 10
filename = [flroot num2str(j1) num2str(j2)];
else
filename = [flroot num2str(j1) '_' num2str(j2)];
end
y = make_gs2input(filename,xpareq,xkt,nbspecies,xspc,xprkn,[ ],zflnm);
end
end
elseif nbs == 3
for j1 = 1:nbofval(1)
for j2 = 1:nbofval(2)
for j3 = 1:nbofval(3)
script2create
if nbofval(1) < 10 & nbofval(2) < 10 & nbofval(3) < 10
filename = [flroot num2str(j1) num2str(j2) num2str(j3)];
else
filename = [flroot num2str(j1) '_' num2str(j2) '_' num2str(j3)];
end
y = make_gs2input(filename,xpareq,xkt,nbspecies,xspc,xprkn,[ ],zflnm);
end
end
end
end
