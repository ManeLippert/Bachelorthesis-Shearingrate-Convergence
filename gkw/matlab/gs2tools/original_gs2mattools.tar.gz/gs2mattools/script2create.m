%
% This is a short script used in create_gs2scan.m
%
for jx = 1:nbs
if yes(jx) == 4 % xpkrn input variable
eval(['xprkn.' vnm{jx} ' = dum(jx).xvals(j' num2str(jx) ');']);
if strcmp(vnm{jx},'beta')
if eval(['dum(jx).xvals(j' num2str(jx) ')']) > 0
xprkn.fapar = 1; else, xprkn.fapar = 0;
end; end;
%
elseif yes(jx) == 3  % species input variable
%
if spcidx(jx) < 3  % assigns to ions or electrons
eval(['xspc(spcidx(jx)).' vnm{jx} ' = dum(jx).xvals(j' num2str(jx) ');']);
else % assigns to both
eval(['xspc(1).' vnm{jx} ' = dum(jx).xvals(j' num2str(jx) ');']);
eval(['xspc(2).' vnm{jx} ' = dum(jx).xvals(j' num2str(jx) ');']);
end
%
elseif yes(jx) == 2 % ktheta input variable
eval(['xkt.' vnm{jx} ' = dum(jx).xvals(j' num2str(jx) ');']);
if strcmp('aky_min', vnm{jx}); xkt.aky_max  = xkt.aky_min; end;
%
if strcmp('aky_max', vnm{jx}); xkt.aky_min  = xkt.aky_max; end;

%
elseif yes(jx) == 1 % equilibrium input variable
eval(['xpareq.' vnm{jx} ' = dum(jx).xvals(j' num2str(jx) ');']);
end
end
%
%
if optc %include collisions
xspc = insert_collisionality(xspc, ne, Tref, Rtor);
end
%
if optz %include impurities
nbspecies = 3;
[xspc, xprkn] = insert_impurity(xspc, xprkn, Zeff, Zimp, Aimp);
end
%
%
