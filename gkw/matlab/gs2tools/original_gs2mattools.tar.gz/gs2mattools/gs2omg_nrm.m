function y = gs2omg_nrm(tref, mref, aref);
% function y = gs2omg_nrm(tref, mref, aref);
%     y = 0.437*sqrt(tref/(2*mref))/aref;
% Note aref is the reference length used in GS2 input
% usually we take aref = R = 1.65 m for AUG !
% Output frequency in MHz !
% actually, it is a circular frequency, so that output 
% is in 10^6 rad/s
%

if ~exist('tref');
     tref = input('Give the Reference Temperature [keV]   ');
end;
if ~exist('mref');
     mref = input('Give the Reference mass [AMU]   ');
end;
if ~exist('aref');
     aref = input('Give the Reference length [m]   ');
end;

y = 0.437*sqrt(tref/(2*mref))/aref;

