function [fields, eigenf, thetasq_av, kperpGS2_av, akyin, kpar_av, kperp_avOLD] = read_gs2field_eigenf(flnm,pth_fld,pth_eign,pth_inpt,figopt)
%
% function [fields, eigenf, thetasq_av, kperpGS2_av, akyin, kpar_av, kperp_avOLD] = read_gs2field_eigenf(flnm,pth_fld,pth_eign,pth_inpt,figopt)
%
% Input. 
%       flnm :  filename
%       pth_fld   :  path (optional: by default looks in user's directory ~/gs2run/fields)
%       pth_eign  :  path (optional: by default looks in user's directory ~/gs2run/eigenf)
%       pth_inpt  :  path (optional: by default looks in user's directory ~/gs2run/input)
% Output.
%       fields & eigenf structures containing arrays
%       thetasq_av :   average on theta square computed over phi square
%       kperp_av   :   kperp value (sqrt of kperpsquare average) 
%                      computed with kx = ky*shat*sqrt(thetasqav)
%       akyin      :   corresponding values of aky given in the gs2 input
%
% CLA 08.09.03
%

usrnm = find_usrnm;
%
if ~exist('pth_fld')
pth_fld = ['/u/' usrnm '/gs2run/fields/'];
end
if ~exist('pth_eign')
pth_eign = ['/u/' usrnm '/gs2run/eigenf/'];
end
if ~exist('pth_inpt')
pth_inpt = ['/u/' usrnm '/gs2run/input/'];
end
if ~exist('figopt')
figopt=1;
end

if pth_fld == 1
pth_fld = ['/u/' usrnm '/gs2run/gs2archive/fields/'];
end
if pth_eign == 1
pth_eign = ['/u/' usrnm '/gs2run/gs2archive/eigenf/'];
end
if pth_inpt == 1
pth_inpt = ['/u/' usrnm '/gs2run/gs2archive/input/'];
end

[zeql b c xkt] = read_gs2input(flnm, pth_inpt);
clear b c;

totflnm = [pth_fld flnm]; 
eval(['[s, aa] = unix(''ls ' totflnm ''');']);
if strncmp(aa(end-4:end), 'tory',4)
for jk = 1:xkt.naky
disp(' '); disp(['INPUT FILE  ' flnm ' !!!! FIELDS and EIGENF FILES NOT IN OUTPUT !!!! ']);
fields(jk).theta =  NaN;
fields(jk).clmn2 =  NaN;
fields(jk).clmn3 =  NaN;
fields(jk).phi_R =  NaN;
fields(jk).phi_I =  NaN;
fields(jk).apar_R = NaN;
fields(jk).apar_I = NaN;
fields(jk).clmn8 =  NaN;
fields(jk).clmn9 =  NaN;
fields(jk).phisq =  NaN;
fields(jk).aparsq = NaN;
%
eigenf(jk).clmn1 = NaN;
eigenf(jk).clmn2 = NaN;
eigenf(jk).clmn3 = NaN;
eigenf(jk).clmn4 = NaN;
eigenf(jk).clmn5 = NaN;
eigenf(jk).clmn6 = NaN;
eigenf(jk).clmn7 = NaN;
eigenf(jk).clmn8 = NaN;
eigenf(jk).clmn9 = NaN;
%
thetasq_av(jk) = NaN;
kperp_av(jk)   = NaN;
akyin = linspace(xkt.aky_min, xkt.aky_max, xkt.naky);
end
return;
end
eval(['load ' totflnm;]);
ipt = find(flnm == '/');
if isempty(ipt)
nmld = flnm;
else
nmld = flnm(ipt+1:end);
end
nmld=corr_minus(nmld);
ipt = find(nmld == '.');
if ~isempty(ipt)
eval(['zfields = ' nmld(1:ipt(1)-1) ';']);
eval(['clear ' nmld(1:ipt(1)-1)]);
else
eval(['zfields = ' nmld ';'])
eval(['clear ' nmld]);
end

totflnm = [pth_fld flnm];
eval(['load ' totflnm;]);
ipt = find(flnm == '/');
if isempty(ipt)
nmld = flnm;
else
nmld = flnm(ipt+1:end);
end
nmld=corr_minus(nmld);
ipt = find(nmld == '.');
if ~isempty(ipt)
eval(['zeigenf = ' nmld(1:ipt(1)-1) ';']);
eval(['clear ' nmld(1:ipt(1)-1)]);
else
eval(['zeigenf = ' nmld ';'])
eval(['clear ' nmld]);
end


[llff b] = size(zfields); clear b;
llth = llff./xkt.naky;

for jk = 1:xkt.naky
fields(jk).theta = zfields((jk-1)*llth+1:jk*llth,1);
fields(jk).clmn2 = zfields((jk-1)*llth+1:jk*llth,2);
fields(jk).clmn3 = zfields((jk-1)*llth+1:jk*llth,3);
fields(jk).phi_R = zfields((jk-1)*llth+1:jk*llth,4);
fields(jk).phi_I = zfields((jk-1)*llth+1:jk*llth,5);
fields(jk).apar_R = zfields((jk-1)*llth+1:jk*llth,6);
fields(jk).apar_I = zfields((jk-1)*llth+1:jk*llth,7);
fields(jk).clmn8 = zfields((jk-1)*llth+1:jk*llth,8);
fields(jk).clmn9 = zfields((jk-1)*llth+1:jk*llth,9);
fields(jk).phisq = fields(jk).phi_R.^2 + fields(jk).phi_I.^2;
fields(jk).aparsq = fields(jk).apar_R.^2 + fields(jk).apar_I.^2;
%
eigenf(jk).clmn1 = zeigenf((jk-1)*llth+1:jk*llth,1);
eigenf(jk).clmn2 = zeigenf((jk-1)*llth+1:jk*llth,2);
eigenf(jk).clmn3 = zeigenf((jk-1)*llth+1:jk*llth,3);
eigenf(jk).clmn4 = zeigenf((jk-1)*llth+1:jk*llth,4);
eigenf(jk).clmn5 = zeigenf((jk-1)*llth+1:jk*llth,5);
eigenf(jk).clmn6 = zeigenf((jk-1)*llth+1:jk*llth,6);
eigenf(jk).clmn7 = zeigenf((jk-1)*llth+1:jk*llth,7);
eigenf(jk).clmn8 = zeigenf((jk-1)*llth+1:jk*llth,8);
eigenf(jk).clmn9 = zeigenf((jk-1)*llth+1:jk*llth,9);
end

kkyy = linspace(xkt.aky_min, xkt.aky_max, xkt.naky);
if figopt
figure; set(gcf,'position', [504     7   764   927]);
for jk = 1:xkt.naky
subplot(xkt.naky,1,jk);
plot(fields(jk).theta, fields(jk).phisq);
if jk == 1
title([corr_underscore(flnm) ' - |\Phi|']);
end
legend(['|\Phi|, aky = ' num2str(kkyy(jk))] );
end

figure; set(gcf,'position', [504     7   764   927]);
for jk = 1:xkt.naky
plot(fields(jk).theta, fields(jk).phi_R,'b-');
hold on
plot(fields(jk).theta, fields(jk).phi_I,'b-');
plot(fields(jk).theta, fields(jk).apar_R,'r-');
hold on
plot(fields(jk).theta, fields(jk).apar_I,'r-');
end
title([corr_underscore(flnm) ' - Fields']);
end

clear outflnm;
totflnm = [pth_inpt flnm];
for ij = 1:length(totflnm)-5; 
if strcmp('input', totflnm(ij:ij+4)); break; end;
end;
outflnm(1:ij-1) = totflnm(1:ij-1);
outflnm(ij:ij+2) = 'out';
outflnm(ij+3:length(totflnm)-2) = totflnm(ij+5:end);
fptr = fopen(outflnm); frewind(fptr);
for jk=1:xkt.naky;
yk = 0;
while yk==0
aaa = fgetl(fptr);
if length(aaa) > 4;
if strcmp(aaa(1:4), 'gds2'); yk = 1; end;
if strcmp(aaa(1:4), 'ky= '); yk = 2; end;
end;
end;
if yk==1;
bbb = fscanf(fptr,'%g', [2 length(fields(jk).theta)]);
fields(jk).gds2   = bbb(1,:)';
fields(jk).kperp2 = bbb(2,:)';
else
fields(jk).gds2   = fields(jk).theta.*NaN;
fields(jk).kperp2 = fields(jk).theta.*NaN;
end;
end;
fclose(fptr);

for jk = 1:xkt.naky
%ith = find(fields(jk).theta > -3.5*pi & fields(jk).theta < 3.5*pi );
ith = find(fields(jk).theta > -10*pi & fields(jk).theta < 10*pi );
zdtheta = diff(fields(jk).theta(ith));
dtheta = [zdtheta(1)./2; zdtheta(1:end-1); zdtheta(end)./2];
at(jk) = trapz(fields(jk).phisq(ith).*dtheta);
bt(jk) = trapz(fields(jk).theta(ith).^2.*fields(jk).phisq(ith).*dtheta);
ct(jk) = trapz(fields(jk).kperp2(ith).*fields(jk).phisq(ith).*dtheta);
dphiRdtheta = gradient(fields(jk).phi_R)./gradient(fields(jk).theta);
dphiIdtheta = gradient(fields(jk).phi_I)./gradient(fields(jk).theta);
moddphidtheta = sqrt(dphiRdtheta.^2+dphiIdtheta.^2);
dt(jk) = trapz((fields(jk).phisq(ith)).^2.*dtheta);
et(jk) = trapz( sqrt(fields(jk).phisq(ith)).*moddphidtheta(ith).*dtheta);
%et(jk) = trapz( (gradient(fields(jk).phisq(ith))./gradient(fields(jk).theta(ith))).^2.*dtheta);
%et(jk) = trapz(gradient(gradient(fields(jk).phisq(ith)) ...
%./gradient(fields(jk).theta(ith)))./gradient(fields(jk).theta(ith)).*dtheta);
end
thetasq_av = bt./at;
if isfield(zeql, 'shat');
zshat = zeql.shat;
z1ovq = zeql.pk./2;
elseif isfield(zeql, 's_hat_input');
zshat = zeql.s_hat_input;
z1ovq = 1./zeql.qinp;
end
kperp_avOLD = sqrt(kkyy.^2.*(1+thetasq_av.*zshat^2) );
kperpGS2_av = sqrt(ct./at./2);
kpar_av = z1ovq.*et./at;
if isnan(kperpGS2_av(1));
disp(' !!!  GS2 kperp not available in output  !!!')
disp('    Simple ky^2 (1 + s^2theta^2) is used')
kperpGS2_av = kperp_avOLD;
end
akyin = kkyy;
