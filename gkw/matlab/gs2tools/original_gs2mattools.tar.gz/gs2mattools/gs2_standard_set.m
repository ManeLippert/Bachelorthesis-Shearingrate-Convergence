%%% Main parameters to be assigned %%%
xpareq.eps   = 0.16;
%xpareq.eps   = 0.1891;
xpareq.epsl  = 2.0;
xpareq.pk    = 1.33;
xpareq.pk    = 1.2;
xpareq.shat  = 0.9;
%xpareq.shat  = 1.5;
%for frr AUG#17504
xpareq.eps   = 0.22;
xpareq.pk    = 0.7143;
xpareq.shat  = 1.5;
%xpareq.eps   = 0.18;
%xpareq.pk    = 1;
%xpareq.shat  = 1;

xpareq.shift  = 0;

%
xkt.naky       =4;
xkt.ntheta0    =1;
xkt.aky_min    =0.05;
xkt.aky_max    =0.2;
xkt.theta0_min =0.0;
xkt.theta0_max =0.0;
%
nbspecies = 2;
%
xspc(1).z = 1.0;
xspc(1).mass = 1.0;
xspc(1).dens = 1.0;
xspc(1).temp = 1;
xspc(1).tprim = 9;
xspc(1).fprim = 1;
xspc(1).uprim = 0.0;
xspc(1).vnewk = 0.0;
%
xspc(2).z = -1.0;
xspc(2).mass = 2.72e-4;
xspc(2).dens = 1.0;
xspc(2).temp = 1;
xspc(2).tprim = 9;
xspc(2).fprim = 1;
xspc(2).uprim = 0.0;
xspc(2).vnewk = 0.0;
%
xprkn.beta = 0.0;
xprkn.zeff = 1.0;
xprkn.fphi = 1.0;
xprkn.fapar = 0.0;
xprkn.faperp = 0.0;
