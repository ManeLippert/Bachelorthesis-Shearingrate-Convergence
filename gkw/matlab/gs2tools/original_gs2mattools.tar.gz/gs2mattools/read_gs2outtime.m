function [aky, omavg, qheat, pflux, ky, iconv] = read_gs2outtime(flnm, pth, opt)
%
% function [aky, omavg, qheat, pflux, ky, iconv] = read_gs2outtime(flnm, [pth, opt])
%
% Reads and plots the time evolution of eigenvalues saved in a gs2 output.
% Asks for values to be accepted on prompt. If the user accepts,
% returns the last values, otherwise returns NaN.
%
% Input. 
%       flnm :  filename
%       pth  :  path (optional: by default looks in user's directory ~/gs2run/output)
%       opt  :  1/0 opt = 1 does not plot the figure and does not ask for acceptance
%               saves directly the values
%               (optional, default is 0; 1 to be used ONLY when the output has been
%                previously checked, checked convergence and checked field plots)
%               if opt is 0, does not close the file in input
% Output.
%       aky   : vector of k_theta values
%       omavg : matrix with complex frequency for each k_theta 
%               omavg(:,1) : real frequency
%               omavg(:,2) : growth rate
%               same normalisations as in gs2 output !
%       qheat and pflux : matrix with heat and particle fluxes 
%                         (same normalisations as in gs2)
%
%       ky    : structure with the full time evolution of all the quantities
%
%       iconv : 1/0 if converged or not
%
% CLA 10.08.03 (updated 1.07.04)
%

usrnm = find_usrnm;
%
if ~exist('pth')
pth = ['/u/' usrnm '/gs2run/output/'];
end
if isempty(pth)
pth = ['/u/' usrnm '/gs2run/output/'];
end
if pth == 1
pth = ['/u/' usrnm '/gs2run/gs2archive/output/'];
end

if ~exist('opt')
opt = 0;
end

totflnm = [pth flnm];
fptr = fopen(totflnm, 'r');
frewind(fptr);
%
iconv = 0;
yk = 0;
while yk == 0
sss = fscanf(fptr,'%s', 1);
if isempty(sss); break; end;
if strcmp(sss, 'converged'), iconv = 1; end;
end

frewind(fptr);
nbspc = 2;
qheat(1,1:nbspc) = NaN;
pflux(1,1:nbspc) = NaN;
ik = 0;
yesik = 0;
while yesik == 0
% looks for locations of aky
yk = 0;
while yk == 0
sss = fscanf(fptr,'%s', 1);
if isempty(sss), yesik = 1; break; end; 
if strcmp(sss, 'aky='), yk = 1; end;
end
if yk == 1
ik = ik+1;
zaky(ik) = fscanf(fptr, '%f', 1);
zyk = 0;
while zyk == 0
sss = fscanf(fptr,'%s', 1);
if strcmp(sss, 'omavg/(vt/a)='), zyk = 1; end;
end
zomavg(ik,1) = fscanf(fptr, '%f', 1);
zomavg(ik,2) = fscanf(fptr, '%f', 1);
zyk = 0;
while zyk == 0
sss = fscanf(fptr,'%s', 1);
if strcmp(sss, 'qheat='), zyk = 1; end;
end
zqheat(ik,1) = fscanf(fptr, '%f', 1);
zqheat(ik,2) = fscanf(fptr, '%f', 1);
aa = fscanf(fptr, '%f', 1);
if ~isempty(aa); zqheat(ik,3) = aa; 
nbspc = 3; 
qheat(1,1:nbspc) = NaN;
pflux(1,1:nbspc) = NaN;
end;
zyk = 0;
while zyk == 0
sss = fscanf(fptr,'%s', 1);
if strcmp(sss, 'pflux='), zyk = 1; end;
end
zpflux(ik,1) = fscanf(fptr, '%f', 1);
zpflux(ik,2) = fscanf(fptr, '%f', 1);
aa = fscanf(fptr, '%f', 1);
if ~isempty(aa); zpflux(ik,3) = aa; end;
end
end
%
frewind(fptr)
ik = 0;
yesik = 0;
while yesik == 0
% looks for locations of time
yk = 0;
while yk == 0
sss = fscanf(fptr,'%s', 1);
if isempty(sss), yesik = 1; break; end; 
if strcmp(sss, 'time='), yk = 1; end;
end
if yk == 1
ik = ik+1;
time(ik) = fscanf(fptr, '%f', 1);
end
end
%
if opt
 fclose(fptr);
end
%
%%%%%%%%%%%%%%%%%%%%
%
idx_aky1 = find(abs(zaky(2:end) - zaky(1)) < 1.e-04);
idx_aky1 = [1 idx_aky1+1];
nbaky = length(zaky)./length(idx_aky1);
for ij = 1:nbaky
ky(ij).aky = zaky(idx_aky1 + (ij-1));
ky(ij).omavg = zomavg(idx_aky1 + (ij-1),:);
ky(ij).qheat = zqheat(idx_aky1 + (ij-1),:);
ky(ij).pflux = zpflux(idx_aky1 + (ij-1),:);
ky(ij).time  = time;
end
%
if opt == 0
figure;
set(gcf,'position', [504     7   764   927]);
for ij = 1:nbaky
if nbaky > 1
subplot(ceil(nbaky/2),2,ij)
end
plot(time,ky(ij).omavg,'-')
hold on
ax = axis;
text(ax(1)+(ax(2)-ax(1))*0.7, ...
     ax(3)+(ax(4)-ax(3))*0.9, ...
     ['aky = ' num2str(ky(ij).aky(1))]);
legend('\omega_r','\gamma',0);
xlabel('time');
if ij == 1
title(corr_underscore(flnm));
end
end
end

%o_btn = uicontrol;
%set(o_btn,'position',[524     20   200   100]);
%set(o_btn,'style','pushbutton');
%btn_text = 'Accept';  
%set(o_btn,'string',btn_text);
%set(o_btn,'FontSize',13);
%set(o_btn,'FontWeight','demi');
%set(o_btn,'callback', 'yacc = 1');

for ij = 1:nbaky
if opt == 0
yacc(ij) = input(['Accept for aky = ' num2str(ky(ij).aky(1)) ' ?    (0/1)  ']);
else
yacc(ij) = 1;
end

aky(ij) = ky(ij).aky(1);
if yacc(ij) ~= 0
omavg(ij,:) = ky(ij).omavg(end,:);
qheat(ij,:) = ky(ij).qheat(end,:);
pflux(ij,:) = ky(ij).pflux(end,:);
else
omavg(ij,:) = [NaN NaN];
qheat(ij,:) = NaN*ones(size(qheat(1,:)));
pflux(ij,:) = NaN*ones(size(qheat(1,:)));
end
end

