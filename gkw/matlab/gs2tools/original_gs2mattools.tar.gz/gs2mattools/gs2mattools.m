%
% *****  WELCOME IN GS2MATTOOLS  *****
%
%   Here is a list of matlab functions and scripts 
%   available in GS2MATTOOLS :
%
% - Reading input/output
%    read_gs2input
%    read_gs2output
%    read_gs2outtime
%    read_gs2field_eigenf
%
% - Reading from ARP IDL interface (could need an update)
%    read_arp_2_stset
%
% - creating the input
%    make_gs2input
%    make_akymax_input
%
% - creating and reading some scans
%    create_gs2scan  
%    create_gs2nuscan            
%    read_gs2scan
%
% - including collisionality or impurities in an input file
%    insert_collisionality     
%    insert_impurity           
%
% - interpolation on a aky spectrum
%    interp_aky                
%
% - normalisation frequency
%    gs2omg_nrm               
%
% - script initialising a standard set 
%    gs2_standard_set
%
%  You can copy /u/cla/matlab/gs2_standard_set.m on your own 
%  matlab directory and modify it to create your inputs !
%
%
% To get the help of any function, please type
% >> help function_name
%
%
% CLA, 03.2004
%
