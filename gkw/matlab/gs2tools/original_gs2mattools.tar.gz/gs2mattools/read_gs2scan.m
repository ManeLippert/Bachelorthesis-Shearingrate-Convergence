function [ky,anrate,anfreq,heatflx,partflx,eql,spc1,spc2,tprim1,tprim2,fprim1,fprim2,temp1,temp2,xprkn] = ...
read_gs2scan(flroot, idx1m, idx2m, pth, pthin);
%
% function [ky,anrate,anfreq,heatflx,partflx,eql,spc1,spc2,tprim1,tprim2,fprim1,fprim2,temp1,temp2,xprkn] = ...
% read_gs2scan(flroot, idx1m, idx2m, [pth, pthin]);
% Max scans on 2 variables.
%
% Input. 
%       flroot :  root of the filenames
%       idx1m, idx2m : min and max indexes of the scan respectively on the first and second variable
%       e.g. for a scan with 8 values [1 8] if you want to read all the output files.
%       If the scan is only on one variable, do not give idx2m, or live it empty.
%       pth    :  path of the output file
%              (optional: by default looks in user's directory ~/gs2run/output)
%       pthin  :  path of the input file
%              (optional: by default looks in user's directory ~/gs2run/input)
%
% Output.
%        ky : structure containing the k_theta values, as well as all the other data
%        anrate :  growth rate
%        anfreq : real frequency
%        heatflx : heat flux (for electrons)
%        partflx : particle flux (for electrons)
%        eql : structure with equilibrium parameters
%        spc1 : structure with first species parameters
%        spc2 : structure with second species parameters
%        tprim1, tprim2 , fprim1, fprim2, temp1, temp2 :
%             first and second species parameters in the
%             form of arrays to allow plots and contour plots
%        xprkn : strucutre with other parameters and knobs
%                (beta, zeff, fphi, fapar, fperp)
%
%        creates output file gs2scan_out in matlab directory
%
% CLA 10.08.03
%

usrnm = find_usrnm;
%
if ~exist('pth')
pth = ['/u/' usrnm '/gs2run/output/'];
end
if ~exist('pthin')
pthin = [pth(1:end-7) 'input/'];
end
if pth == 1
pth = ['/u/' usrnm '/gs2run/gs2archive/output/'];
end
if pthin == 1
pthin = ['/u/' usrnm '/gs2run/gs2archive/input/'];
end

%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
if ~exist('idx2m')
     idx2m = [1 1];
end
if isempty(idx2m)
     idx2m = [1 1];
end
%
clear anrate anfreq heatflx partflx tprim1 tprim2 fprim1 fprim2 temp1 temp2
anrate = NaN*ones(idx1m(2),idx2m(2));
anfreq = anrate; heatflx = anrate; partflx = anrate;
tprim1 = anrate; tprim2 = anrate; fprim1 = anrate; fprim2 = anrate;
temp1 = anrate; temp2 = anrate;
for ij = idx1m(1):idx1m(2)       % first  index
for ii = idx2m(1):idx2m(2)       % second index
[ij ii]
if idx1m(2) < 10 & idx2m(2) < 10
flnm = [flroot num2str(ij) num2str(ii)];
else
flnm = [flroot num2str(ij) '_' num2str(ii)];
%flnm = [flroot num2str(ij) num2str(ii)];
end
if idx2m(2) == 1
flnm = [flroot num2str(ij)];
end
[ky(ij,ii).aky, ky(ij,ii).omavg, ky(ij,ii).qheat, ky(ij,ii).pflux] = ...
read_gs2output(flnm, pth);
[eql(ij,ii) spc xprkn(ij,ii)] = ...
read_gs2input(flnm, pthin);
for js = 1:length(spc)
     eval(['spc' num2str(js) '(ij,ii) = spc(' num2str(js) ');']);
end
if (isnan(ky(ij,ii).omavg(1)))
     disp([' Run ' num2str(ij) ' ' num2str(ii) ' not converged']);
end
[anrate(ij, ii) im] = max(ky(ij,ii).omavg(:, 2));
anfreq(ij, ii) = ky(ij,ii).omavg(im, 1);
			  mky = ky(ij,ii).aky(im);
heatflx(ij, ii) = ky(ij,ii).qheat(im, 2);
partflx(ij, ii) = ky(ij,ii).pflux(im, 2);
tprim1(ij, ii) = spc1(ij,ii).tprim;
tprim2(ij, ii) = spc2(ij,ii).tprim;
fprim1(ij, ii) = spc1(ij,ii).fprim;
fprim2(ij, ii) = spc2(ij,ii).fprim;
temp1(ij, ii) = spc1(ij,ii).temp;
temp2(ij, ii) = spc2(ij,ii).temp;
end
end;
%
%
opt = 0;
%
if opt == 1
for ii = idx2m(1):idx2m(2)
figure(ii);clf;
set(gcf,'position', [683   136   560   774]);
set(gcf,'paperposition', [2.59447155556   3.919908111  15.79243555556  21.827402]);
end
for ij = idx1m(1):idx1m(2)       % first  index
for ii = idx2m(1):idx2m(2)
flnm = ['rlne' num2str(ij) '.' num2str(ii)];
figure(ii);
subplot(4,1,ij)
plot(ky(ij,ii).aky, ky(ij,ii).omavg(:,2),'*-');
xlabel('aky');
ylabel('Im(omavg)');
grid on
ax = axis;
text(ax(1)+(ax(2)-ax(1))*0.05, ax(3)+(ax(4)-ax(3))*0.85, flnm);
hold on
end
end
%
end
opt = 0;
if opt == 10
if tprim1(idx1m(1), idx2m(1)) ~= tprim1(idx1m(1)+1, idx2m(1)); is1 = 1; 
n1dum = 'R/L_Ti'; x1dum = tprim1(idx1m(1):idx1m(2),idx2m(1))'; end;
if tprim2(idx1m(1), idx2m(1)) ~= tprim2(idx1m(1)+1, idx2m(1)); is1 = 2; 
n1dum = 'R/L_Te'; x1dum = tprim2(idx1m(1):idx1m(2),idx2m(1))'; end;
if fprim1(idx1m(1), idx2m(1)) ~= fprim1(idx1m(1)+1, idx2m(1)); is1 = 3; 
n1dum = 'R/L_n '; x1dum = fprim1(idx1m(1):idx1m(2),idx2m(1))'; end;
if temp1(idx1m(1), idx2m(1))  ~= temp1(idx1m(1)+1, idx2m(1));  is1 = 4; 
n1dum = 'Ti    '; x1dum = temp1(idx1m(1):idx1m(2),idx2m(1))';  end;
if temp2(idx1m(1), idx2m(1))  ~= temp2(idx1m(1)+1, idx2m(1));  is1 = 5; 
n1dum = 'Te    '; x1dum = temp2(idx1m(1):idx1m(2),idx2m(1))';  end;
is2 = 0;
if idx2m(2) > 1
if tprim1(idx1m(1), idx2m(1)) ~= tprim1(idx1m(1), idx2m(1)+1); is2 = 1; 
n2dum = 'R/L_Ti'; x2dum = tprim1(idx1m(1),idx2m(1):idx2m(2));  end;
if tprim2(idx1m(1), idx2m(1)) ~= tprim2(idx1m(1), idx2m(1)+1); is2 = 2; 
n2dum = 'R/L_Te'; x2dum = tprim2(idx1m(1),idx2m(1):idx2m(2));  end;
if fprim1(idx1m(1), idx2m(1)) ~= fprim1(idx1m(1), idx2m(1)+1); is2 = 3; 
n2dum = 'R/L_n '; x2dum = fprim1(idx1m(1),idx2m(1):idx2m(2));  end;
if temp1(idx1m(1), idx2m(1))  ~= temp1(idx1m(1), idx2m(1)+1);  is2 = 4; 
n2dum = 'Ti    '; x2dum = temp1(idx1m(1),idx2m(1):idx2m(2));   end;
if temp2(idx1m(1), idx2m(1))  ~= temp2(idx1m(1), idx2m(1)+1);  is2 = 5; 
n2dum = 'Te    '; x2dum = temp2(idx1m(1),idx2m(1):idx2m(2));   end;
end
fptr = fopen(['/u/' usrnm '/matlab/gs2scan_out'],'w');
frewind(fptr);
fprintf(fptr,'%s \n', ['% Scan ' flroot ' output']);
if idx2m(2) == 1
fprintf(fptr, '%s \n', ...
['% R/L_Ti = ' num2str(tprim1(idx1m(1),idx2m(1))) ...
' R/L_Te = ' num2str(tprim2(idx1m(1),idx2m(1))) ...
' R/L_n = ' num2str(fprim1(idx1m(1),idx2m(1))) ...
' Ti = ' num2str(temp1(idx1m(1),idx2m(1))) ...
' Te = ' num2str(temp2(idx1m(1),idx2m(1)))]);
fprintf(fptr,'%s \n', ['%  ' n1dum '  anrate   anfreq   qheat_e   pflux_e']);
aaa = [x1dum' anrate(idx1m(1):idx1m(2)) anfreq(idx1m(1):idx1m(2)) heatflx(idx1m(1):idx1m(2)) partflx(idx1m(1):idx1m(2))];
fprintf(fptr,'  %4g  %4g  %4g  %4g  %4g \n', aaa');
else
for ij = idx2m(1):idx2m(2)
fprintf(fptr,'%s \n', ['%  ' n2dum ' = ' num2str( x2dum(ij-idx2m(1)+1) )]);
fprintf(fptr,'%s \n', ['%  ' n1dum '  anrate   anfreq   qheat_e   pflux_e']);
aaa = [x1dum' anrate(idx1m(1):idx1m(2),ij) anfreq(idx1m(1):idx1m(2),ij) heatflx(idx1m(1):idx1m(2),ij) partflx(idx1m(1):idx1m(2),ij)];
fprintf(fptr,'  %4g  %4g  %4g  %4g  %4g \n', aaa');
end
end
fclose(fptr);
%
end
